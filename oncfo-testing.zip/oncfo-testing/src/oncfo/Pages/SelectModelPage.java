package oncfo.Pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
public class SelectModelPage extends BasePage {
 public static int i;
public final static By byPrestntModel=findBy("//div[@class='page-actions']");
public final static By bySelectModel=findBy("//button[@class='btn dropdown-toggle blue']");
public final static By bySelectModelName=findBy("//div[@class='dropdown-menu open']//a[@class='op']");
public final static By byModel=findBy("//li[@data-original-index='129']");

///////////////////////Validator///////////////////////////////
public static boolean isModelNamepresent(){
		return isElementPresent(byPrestntModel, "Model Name");
}

public static void selectModelName(){
	List<WebElement>list=findElements(bySelectModelName,"Model");
	 i=list.size()-1;
	clickElementFromList(bySelectModelName, "model",i );
 
}

public static void SelectModel(){
		sleepApplication(3000);
		HoverandClikcActionsElement(byPrestntModel,"Select Module");
		sleepApplication(6000);
		waitForPageLoad(10);
		selectModelName();
		sleepApplication(10000);
		
	}
}
