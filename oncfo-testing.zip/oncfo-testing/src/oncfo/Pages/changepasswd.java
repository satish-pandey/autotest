package oncfo.Pages;

import org.openqa.selenium.By;
public class changepasswd extends BasePage{
	public final static By byChangepasswd=findBy("//a[@href='changePassword']");
	public final static By byAccountUsername =findBy("//div[contains(text(),'Animesh Singh')]");
	public final static By byOldPassword = findBy("//input[@id='oldPassword']"); 
	public final static By byNewPassword=findBy("//input[@id='newPassword']");
	public final static By byConfirmpasswd=findBy("//input[@id='pwd']");
	public final static By bySubmitButton=findBy("//button[contains(text(),'Submit')]");
	public static void clickOldpasswd(){
		clickElement(byOldPassword, "click old password");
	}
	public static void clickSubmitButton(){
		clickElement(bySubmitButton,"submit button");
	}
	public static void OldPassword(String sText){
		setText(byOldPassword, "Old Password", sText);
	}
	public static void NewPassword(String sText){
		setText(byNewPassword, "New Password", sText);
	}
	public static void cnfirmPassword(String sText){
		setText(byConfirmpasswd, "cnfirm Password", sText);
	}
	
	public static void passwordchangeverify(String oldpasswd,String NewPasswd,String cnfirmPasswd){
		HoverActionsElement(byAccountUsername, "By account username");
		clickActionsElement(byChangepasswd, "by change password");
		OldPassword(oldpasswd);
		NewPassword(NewPasswd);
		cnfirmPassword(cnfirmPasswd);
		clickSubmitButton();
		
		
	}
}
