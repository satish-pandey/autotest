package oncfo.Pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
public class centralizedAssumptionVertical extends BasePage{
public final static By byupdateInitialValue=findBy("//*[@id='parent']/table/tbody/tr[1]/td[5]");
public final static By byAssumptiontab=findBy("//span[contains(text(),'Assumption')]");
public final static By bycountroww = findBy("//div[@class='op']");
public final static By byverticalIcon=findBy("//div[@id='normalView']/div/div/div/div[2]/a[1]/i");
//public final static By byHorizontal=findBy("//*[@id='normalView']/div/div/div[2]/a[2]/i");
public final static By byHorizontal=findBy("//div[@id='normalView']/div/div/div/div[2]/a[2]/i");
public final static By bySelectdashboard=findBy("//select[@class='form-control input-large horizontal_view']");
public final static By bySelectByHorizontal=findBy("//div[@id='bottom-screen-varti']/div[2]/select");
public final static By bySelecttimeperiod=findBy("//*[@id='parent']/table/tbody/tr[3]/td[2]/select");
public final static By byEditTd=findBy("//table//tr[1]//td[5]");
public final static By byFillRight=findBy("//div[@id='normalView']/div/div/div/div[2]/a[3]/i");
public final static By bySaveScenario=findBy("//a[contains(text(),'Save Scenario')]");
public final static By byVerticaView=findBy("//h1[contains(text(),'Verticle View')]");
public final static By byHorizontalView=findBy("//h1[contains(text(),'Horizontal View')]");
public final static By byTablePresent=findBy("//div[@id='parent']");
public final static By byRowForVertical=findBy("//tr[@role='row']");
public final static By bycompareInt=findBy("//tr[@role='row']/td[4]");
public final static By bytext=findBy(".//*[@id='22680_${view1}']");
public final static By byUpdateMsg=findBy("//img[@src='resources/image/logo.png']");
public final static By byDashboard=findBy("//h1[contains(text(),'Dashboard')]");
////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////Validation////////////////////////////////////////////////////////////////////////
public static boolean isUpdateMsgPresent(){
return isElementPresent(byUpdateMsg, "Update Message ");
}
public static boolean isDashboardPresent(){
	return isElementPresent(byDashboard,"Dashboard");
}


////////////////////////////////////CLICKER/////////////////////////////
public static void clickverticalIcon(){
	//select[@class='form-control input-sm monthly']
	clickElement(byverticalIcon, "on Vertical");
}
public static void clickOnSelecttimeperiod(String sText){
	//	java.util.List<WebElement> timePeriod=findElements(bySelecttimeperiod, "timePeriod");
	//	timePeriod.get(1).click();
	
		setSelectBoxValue(bySelecttimeperiod,"Mont" , sText);
	}
public static void setTextdata(String sText){
	
	setText(byEditTd, "Data", sText);
}
public static void clickOnFillRight(){
	clickElement(byFillRight, "Fill Right");
	
}
public static void clickOnSaveScenario(){
	clickElement(bySaveScenario, "Save Scenario");
	
}
public static void clickOnHorizontal(){
	clickElement(byHorizontal,"Horizontal");
	}
public static void clickOncell(){
	clickActionsElement(byEditTd, "click on cell");
}
///////////////////////validation///////////////
public static boolean isVerticalViewPresent(){
	return isElementPresent(byVerticaView, "Vertical View");
}
public static boolean isHorizontalView(){
	return isElementPresent(byHorizontalView, "Horizontal View");
}
public static boolean isTablePresent(){
	return isElementPresent(byTablePresent, "Table");
}


public static void verifyVerticalAssumption(String Dash,String month){
	HomePage.clickHomeTab();
	HomePage.clickAssumptionTab();
	HomePage.clickCenterlizeTab();
	java.util.List<WebElement> list=findElements(bycountroww, "num fo rosw");
	System.out.println(list.get(3).getText());
	sleepApplication(5000);
	list.get(1).click();
	sleepApplication(1000);
	
	if(!isTablePresent()){
	clickOnSelecttimeperiod(month);
	sleepApplication(5000);
	
	
	clickOncell();
	 sleepApplication(2000);
	//System.out.println(((WebElement)byEditTd).getText());
	Actions act =new Actions(driver);
		    	 
		    	
		    	 act.sendKeys(Keys.BACK_SPACE);
		    	 act.sendKeys(Keys.BACK_SPACE);
		    	 act.sendKeys(Keys.DELETE);
		    	 act.sendKeys(Keys.DELETE);
		    	 sleepApplication(2000);
		    	 act.sendKeys("143").build().perform();
		    	 
		     System.out.println("cell clear");
	  
    sleepApplication(2000);	
	clickOnFillRight();
	sleepApplication(2000);
	clickOnSaveScenario();
	sleepApplication(3000);
	clickverticalIcon();
	sleepApplication(3000);
	setSelectBoxValue(bySelectdashboard, "Dashboard", Dash);
	/*sleepApplication(10000);
	System.out.println("Module selected");
	List<WebElement>RowForVertical=findElements(byRowForVertical, "conunt Row");
	System.out.println(RowForVertical.get(1).getText());
	List<WebElement>comparedata=findElements(bycompareInt, "conunt Row");
	String str=comparedata.get(1).getText();
	System.out.println(str);
	String str1="$20,0";
	
	if(str==str1){
		System.out.println("data updated and matched");
	}
	else{
		System.out.println(str1);
		System.out.println(str);
*/	
	}
	/*AdminEmailLoginPage.EmialLogin("virajsharma522", "8@7654321","Automation_Testing");	
	assertTrue(centralizedAssumptionVertical.isVerticalViewPresent());}
	else{
		System.out.println("Module Not Found");
		logOutPage.logOut();
	}*/
	
}
public static void verifyHorizontalAssumption(String Dash,String month,String value){
	HomePage.clickHomeTab();
	HomePage.clickAssumptionTab();
	HomePage.clickCenterlizeTab();
	java.util.List<WebElement> list=findElements(bycountroww, "num fo rosw");
	System.out.println(list.get(4).getText());
	list.get(2).click();
	sleepApplication(10000);
	System.out.println("clicked on sheet");
	clickOnSelecttimeperiod(month);
	sleepApplication(5000);
	/*DoubleClikcActionsElement(byEditTd,"double click");
	System.out.println("double clicked");*/
	//List<WebElement>text=findElements(byEditTd,"text");
//	System.out.println(text.get(1).getText());
//	text.get(1).sendKeys("123");
	//setTextdata(value);
	clickOncell();
	 sleepApplication(2000);
	//System.out.println(((WebElement)byEditTd).getText());
	Actions act =new Actions(driver);
		    	 
		    	
		    	 act.sendKeys(Keys.BACK_SPACE);
		    	 act.sendKeys(Keys.BACK_SPACE);
		    	 act.sendKeys(Keys.DELETE);
		    	 act.sendKeys(Keys.DELETE);
		    	 sleepApplication(2000);
		    	 act.sendKeys("143").build().perform();
		    	 
		     System.out.println("cell clear");
	  

	System.out.println("Filled Value");
	//
	clickOnFillRight();
	sleepApplication(2000);
	clickOnSaveScenario();
	sleepApplication(5000);
	clickOnHorizontal();
	sleepApplication(3000);
	setSelectBoxValue(bySelectByHorizontal, "Dashboard", Dash);
//	java.util.List<WebElement>Selectlist=findElements(bySelectByHorizontal, "horizontal");
//	Selectlist.size();
//	System.out.println(Selectlist.get(1));
	sleepApplication(10000);
		
	
}
}