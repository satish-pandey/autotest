package oncfo.Pages;

import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class AdminEmailLoginPage extends BasePage {
  public final static By byEmailTab=findBy("//input[@id='Email']");
  public final static By byPasswordTab=findBy("//input[@id='Passwd']");
  public final static By bysignInTab=findBy("//input[@id='signIn']");
  public final static By bySearchText=findBy("//input[@name='q']");
  public final static By bySearchTab=findBy("//*[@id='gb']/div[2]/div[3]/div/form/button[3]");
  public final static By byNextButton=findBy("next");
  public final static By byShareMyDrive=findBy("//span[contains(text(),'Shared with me')]");
  public final static By byCurrenUpdateSheet=findBy("//div[@class='l-t-T-j']");
  public final static By bySearchResult=findBy("//div[@class='a-t-cb-oa']/div[@class='l-t-T-j']");
  public final static By bySearchNotGet=findBy("//div[@id='empty-view-title-search']");
  public final static By byImageIcon=findBy("//span[@class='gb_8a gbii']");
  public final static By bySignOutEmail=findBy("//a[@id='gb_71']");
  public final static By byEmailOpen=findBy("//div[@aria-label='AutomationTestingOncfo']");
  public final static By byExcelSheet=findBy("//div[@class='l-u-Ab-zb ta-gc-np-Nd']");
  public final static By byExcelFile=findBy("//div[@class='l-u-Ab-zb ta-gc-np-Nd']");
  public final static By byGoogleDrive = findBy("//div//a[contains(text(),'Go to Google')]");
  
  public static boolean SearchNotPresent(){
	  return isElementPresent(bySearchNotGet, "Not found");
  }
  public static boolean ExcelFileisPresent(){
	  return isElementPresent(byExcelFile,"File");
  }
  public static void clickNextButton(){
	  clickElement(byNextButton, "NextButton");
  }
  public static void clickSearchTab(){
	  clickElement(bySearchTab, "searchTab");
  }
  public static void clickSignIn(){
	  clickElement(bysignInTab, "signIn");
  }
  public static void clickShareMyDrive(){
	  clickElement(byShareMyDrive, "Shared Drive");
  }
  public static void clickOnImageIcon(){
	  clickElement(byImageIcon, "Image Icon");
  }
  public static void clickOnSignOutEmail(){
	  clickElement(bySignOutEmail, "signOut");
  }
  
  public static void clickOnGoogleDrive(){
	  clickElement(byGoogleDrive, "googleDriver");
  }
  
  public static void setEmail(String sText){
	  setText(byEmailTab, "Email Text", sText);
  }
  public static void setSearchText(String sText){
	  setText(bySearchText, "Search Text", sText);
  }
  public static void setPassword(String sText){
	  setText(byPasswordTab,"Password Field" , sText);
  }
  
  public static  void EmialLogin(String Email ,String password,String uploadsheet){
	 /* System.setProperty("webdriver.chrome.driver", "D:\\Software\\Study\\chromedriver.exe");
	  driver = new ChromeDriver();*/
	  System.setProperty("webdriver.gecko.driver",""); 
		driver = new FirefoxDriver();
	  driver.get("https://drive.google.com/");
      driver.manage().window().maximize(); 
      waitForPageLoad(20);
      clickOnGoogleDrive();
      sleepApplication(2000);
      setEmail(Email);
	  clickNextButton();
	  waitForPageLoad(10);
	  setPassword(password);
	  clickSignIn();
	  waitForPageLoad(30);
	  setSearchText(uploadsheet);
	  sleepApplication(1000);
	  Actions act=new Actions(driver);
	  act.sendKeys(Keys.ENTER).build().perform();
	  sleepApplication(5000);
	/* 
	 // java.util.List<WebElement>emailList= findElements(byEmailOpen, "Email List");  
	//  emailList.get(1).click();
	  sleepApplication(3000);
	 // clickElement(byEmailOpen, "EmailIcon");
	//  act.sendKeys(Keys.ENTER).build().perform();
	  java.util.List<WebElement>excelSheet=findElements(byExcelSheet,"Excel sheet");
	  System.out.println( excelSheet.size());
	  excelSheet.get(0).click();
	  sleepApplication(10000);
	  if(SearchNotPresent()){
		  System.out.println("INFO: Search NOt Found");
	  }
	  else {
		System.out.println("INFO: Search Found");
	}
	  clickOnImageIcon();
*/	 
  }
 
}
 