package oncfo.Pages;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class AddModelPage extends BasePage {
	public static String str;
	public final static By byAddModel=findBy("//a[contains(text(),'Add Model')]");
	public final static By byAddFinancialModelName=findBy("//input[@class='form-control input-small in2']");
	public final static By bynewModelButton=findBy("//button[@id='sample_editable_1_new']");
	public final static By byclickSaveButton=findBy("//a[contains(text(),'Save')]");
	public final static By byAddFinancial=findBy("//h1[contains(text(),'Add Financial Model')]");
	public final static By byPrestntModel=findBy("//div[@class='page-actions']");
	public final static By bySelectModelName=findBy("//a[@class='op']");
	public final static By byModelName=findBy(".//*[@id='drop_mou_hov']/div/div/div/div/button");
	public final static By byModel=findBy("//li[@data-original-index='2']");
	
	public final static By byEditModule=findBy("//a[contains(text(),'Edit')]");
	public final static By byModuleArea=findBy("//a[contains(text(),'Module Area')]");
	public final static By byEditModuleArea=findBy("//td[@id='19']/input[@type='text']");
	public final static By bySuccessMsg=findBy("//div[contains(text(),'Sub module area successfully updated')]");
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	public static boolean issuccessPresent(){
		return isElementPresent(byAddFinancial,"Success Message");
	}
	
	public static boolean isSussessMsgPresent(){
		return isElementPresent(bySuccessMsg,"Update Successfully");
	}
		////////////////////////clicker/////////////////////////////////////
	public static void clickonAddModel(){
		clickElement(byAddModel, "by Add Model");
	}
	public static void clickonSavebutton(){
		clickElement(byclickSaveButton, "ON Save Button");
	}
	
	public static void clickNewModelButton(){
		clickElement(bynewModelButton, "by Add New Model Button");
	}
	public static void clicOnModelName(){
		clickElement(bySelectModelName,"model");
	}
	public static void selectModelName(String sText){
		setSelectBoxValue(bySelectModelName,"Model Name", sText);
	}

	public static void clickSelectModel(){
		List<WebElement> ListModel = findElements(bySelectModelName,"Select Model");
		ListModel.get(0).click();
		//clickElement(ListModel.get(4), "Selected Model");
	}
	public static void clickbyModel(){
		clickElement(byModel, "model");
	}
	
	
	public static void clickOnEditModule(){
		clickElementFromList(byEditModule,"Edit Module",1);
	}
	public static void clickOnModuleArea(){
		clickElement(byModuleArea,"Module Area");
	}
	/////////////////////Setter//////////////////////////////////////////
	public static void setModelName(String stext){
		setText(byAddFinancial,"Model Name", stext);
	}
	public static void setModel(String model){
		setText(byAddFinancialModelName, "Add Financial Model Name" , model);
	}
	
	public static void setModuleAreaName(String sText){
		setText(byEditModuleArea,"Module Area ", sText);
	}
	///////////////////////////////////////////////////Helper////////////////////////////////////////////////////
	public static void AddModel(){
		HomePage.clickSettingsTab();
		clickonAddModel();
		waitForPageLoad(10);
		clickNewModelButton();
	    str=getRandomString(5);
		System.out.println("INFO: Created Model Name is : "+str);
		setModel(str);
		clickonSavebutton();
		sleepApplication(10000);
			
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void EditModuleArea(){
		HomePage.clickSettingsTab();
		clickOnModuleArea();
		clickOnEditModule();
		waitForPageLoad(10);
		driver.findElement(byEditModuleArea).clear();
		setModuleAreaName(getRandomString(6));
		clickonSavebutton();
		sleepApplication(5000);
	}
}
