package oncfo.Pages;

import org.openqa.selenium.By;

import Helpers.Helper;
public class Processing_LayerPage extends Helper {
public final static By byprocessingLayer=findBy("//a[@href='processingLayer']"); 
public final static By bySelectMappobject=findBy("//select[@name='fieldName']");
public final static By byMappingObject=findBy("//select[@id='baseObjectName1']");
public final static By bySubmitbutton=findBy("//button[contains(text(),'Submit')]");
public final static By byDashboard=findBy("//h1[contains(text(),'Dashboard')]");
////////////////////////////////////////////Validator//////////////////////////////////////////////////
public static boolean isDashboardPresent(){
	return isElementPresent(byDashboard, "Dashboard");
}


public static void clickProcessingLayer(){
	clickElement(byprocessingLayer, "By processing Layer");
	}
public static void clickonSelect(){
	clickElement(bySelectMappobject, "clik on select");
}
public static void clickOnSubmitButton(){
	clickElement(bySubmitbutton, "By submit button");
	}
public static void VerifyProcessingLayer(String sText,String Text) throws InterruptedException{
	HomePage.clickSettingsTab();
	clickProcessingLayer();
	setSelectBoxValue(bySelectMappobject, "select Value of Box" ,sText);
	waitForPageLoad(500);
	setSelectBoxValue(byMappingObject, "select Mapping object" ,Text);
	waitForPageLoad(500);
	clickOnSubmitButton();
}
}
