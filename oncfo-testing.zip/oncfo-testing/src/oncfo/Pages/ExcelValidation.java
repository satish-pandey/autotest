package oncfo.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class ExcelValidation extends BasePage {
	public final static By byValidateExcelLink = findBy("//a[contains(text(),'Validate Excel')]");
	public final static By byselectFile = findBy("//input[@id='file']");
	public final static By byNextButton = findBy("//button[@class='btn blue btnSub nxtModule']");
	public final static By byValidateFileButton = findBy("//button[@type='submit']");
	public final static By byHeading = findBy("//h1[contains(text(),'Module Error Report')]");
	public final static By byErrorCount=findBy("//table//tbody//tr");
	public final static By byCreateModule=findBy("//span[contains(text(),'Create Module')]");

	////////////////// **** Validation **** /////////////////////////

	public static boolean isHeadingPresent() {
		return isElementPresent(byHeading, "Heading Failed Upload Report");
	}
	public static boolean isValidateExcelLinkPresent() {
		return isElementPresent(byValidateExcelLink, "Validate Excel Link");
	}

	public static void isValidateExcelPage() {
		Assert.assertEquals(driver.getCurrentUrl(), "https://sandbox.onplan.co/validateExcel");
	}

	public static boolean isNextButtonPresent() {
		return isElementPresent(byNextButton, "Next Button");
	}
	////////////////// **** clicker **** /////////////////////////
	public static void clickbValidateFileButton() {
		clickElement(byValidateFileButton, "Validate File Button");
	}
	
	public static void clickNextButton() {
		clickElement(byNextButton, "Next Button");
	}
	
	public static void clickValidateExcelLink() {
		clickElement(byValidateExcelLink, "Validate Excel Link");
	}
	public static int errorCount(){
		 List<WebElement>error=findElements(byErrorCount, "Error count");
		 int ErrorCount=error.size();
		 for (WebElement webElement : error) {
			System.out.println(webElement.getText());
		}
		 return ErrorCount;
	}

	public static void clickOnCreateMOdule(){
		clickElement(byCreateModule,"Create Module");
	}
	////////////////// **** Setter **** /////////////////////////

	public static void uploadExcel(String excelPath) {
		setText(byselectFile, "Select file", excelPath);
	}

	
	//////////////// **** Helper ****  /////////////////////////

	public static void excelValidation(String file) {
		BuildPage.clickBuidTab();
		sleepApplication(5000);
		clickOnCreateMOdule();
		clickValidateExcelLink();
		waitForPageLoad(10);
		uploadExcel(file);
        sleepApplication(5000);
        clickNextButton();
        waitForPageLoad(20);
        System.out.println(" INFO: Error Count is  : "+errorCount());
        clickbValidateFileButton();
        waitForPageLoad(10);
        
        
	}
}
