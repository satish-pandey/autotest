package oncfo.Pages;

import org.openqa.selenium.By;

public class updatemetadaPage extends BasePage {
	public final static By byModules =findBy(".//*[@id='tab_settings']/div/div[1]/div/ul/li[5]/a");
	public final static By byModuleMetadata   =findBy("//a[contains(text(),'Module Metadata')]");
	public static void clickModules(){
		clickElement(byModules, "by Modules tab");
	}
	public static void clickModuleMetadata(){
		clickElement(byModuleMetadata, "by Modules Metadata tab");
	}
	public static void metadataupdate(){
HomePage.clickSettingsTab();
clickModules();
clickModuleMetadata();
	
	}
}