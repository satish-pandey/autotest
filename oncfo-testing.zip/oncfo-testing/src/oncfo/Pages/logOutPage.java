package oncfo.Pages;
import org.openqa.selenium.By;
public class logOutPage extends BasePage {
  
	public final static By byLogOut =findBy("//a[@href='logout']");
	public final static By byAccountUsername =findBy("//img[@src='../frontend/assets/layouts/layout4/img/avatar9.jpg']");
 
	public static boolean isAccountUsernamepresent(){
	return isElementPresent(byAccountUsername, "by Account user name");
	}
	public static void clickLogout(){
		clickElement(byLogOut, "by LogOut button");
	}
	
	public static void logOut() {
		
		HoverActionsElement(byAccountUsername, "By account username");
		clickActionsElement(byLogOut, "logout tab");
		System.out.println("INFO: Logout succesfully from user account");
		
	}
}

