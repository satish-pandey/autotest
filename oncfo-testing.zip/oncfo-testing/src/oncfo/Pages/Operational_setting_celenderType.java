package oncfo.Pages;
import org.openqa.selenium.By;
public class Operational_setting_celenderType extends BasePage{
public final static By byOperationalSetting= findBy("//*[@id='tab_settings']/div/div[1]/div/ul/li[2]/a");  
public final static By Month_Slect =findBy("//*[@id='tab_settings']/div/div[2]/div/div[2]/form/div[1]/div/div/select");
public final static By bySubmitButton=findBy("//button[contains(text(),'Submit')]");
public final static By byMarkBookLog=findBy("//h1[contains(text(),'Mark Book Closing')]");

//////////////////////////////////Validator///////////////////////////////////////////////////////
public static boolean isMarkBookClosingPresent(){
	return isElementPresent(byMarkBookLog,"Mark Book Closing");
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////CLICKER////////////////////////////////////////////////////////////////////////////
public static void clickoperational_Setting(){
	clickElement(byOperationalSetting, "Operational setting");
}
public static void clickOnSubmitButton(){
	clickElement(bySubmitButton, " submit button");
}
public static void Select_Month(String Month){
	HomePage.clickSettingsTab();
	clickoperational_Setting();
	setSelectBoxValue(Month_Slect, "Select Month" ,Month);
	System.out.println("INFO: Month added successfully");
	clickOnSubmitButton();
}

 }
