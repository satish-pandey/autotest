package oncfo.Pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


public class BuildTabModelView extends BasePage {
	public final static By byNew_2ExcelFile=findBy("//li[@id='2' ]//div[@data-parent='2']");
	
	public final static By byLinkedIcon=findBy("//i[@class='fa fa-paperclip fa-2x']");
	public final static By bytdDatatoLink=findBy("//table[@id='sample_1']/tbody/tr[4]/td[2]");
	//table//tr/td[2]/i[@class='fa fa-paperclip fa-2x editValue']
	
	public final static By byNewLinkIcon=findBy("//table[@id='sample_1']/tbody/tr[4]/td[2]/i");
	public final static By bybellIcon=findBy("//table[@id='sample_1']/tbody/tr/td[2]/span");
	public final static By bybellIcon2=findBy("//table[@id='sample_1']/tbody/tr[4]/td[2]/i[2]");
	
	public final static By bySearchText=findBy("//input[@id='search']");
	public final static By byModuletoLink=findBy("//li[@class='childLi']");
	public final static By byAddNewRowTab=findBy("//button[@id='add_row_in_google_sheet']");
	public final static By bySaveButton=findBy("//input[@value='Save']");
	/////////////////////Module//////////////////
	public final static By byModuleAssumption=findBy("//a[contains(text(),'Module Assumption')]");
	public final static By byFormulaView=findBy("//a[contains(text(),'Formula View')]");	
	public final static By byAddNewRowData=findBy("//*[@id='editGoogleMetadata']/tbody/tr[1]/td/input");
	public final static By byAddNewRow=findBy("//button[@id='add_row_in_google_sheet']");
	public final static By byFormulTd=findBy("//*[@id='googleformula']/tbody/tr[3]/td[5]/input");
	public final static By byEditFormula=findBy("//input[@id='formulaBar']");
	public final static By byModulLibrary=findBy("//*[@id='timeseries_table3_filter']/label");
	public final static By byModuleLibrary=findBy("//*[@id='tab_build']/div/div[2]/div/div[2]/div[2]/div[1]");
	public final static By  byQTestModuleArea=findBy("//a[@class='nav-link loadingBar']");
	
	public final static By byAboutModule=findBy("//a[contains(text(),'About Module')]");
	public final static By byNext=findBy(".//*[@id='sample_1_paginate']/ul/li[5]/a");
	//td[@class='bg_color fx_colum']/i[@class='fa fa-paperclip fa-2x editValue']
		
	
	public final static By byNew2HomelFile=findBy("//li[@id='2']//li[@data-parent='2']");
	public final static By byQuaterly=findBy("//*[@id='select_timeseries_duration']/label[2]");
	public final static By byAddToDashSuccessMessage=findBy("//div[contains(text(),'Module Already exist')]");
	public final static By byAddToDashBoard=findBy("//span[contains(text(),'Add to')]");
	public final static By byLinkedData=findBy("//table//tbody//tr//td[2]//i[@class='fa fa-paperclip fa-2x']");
	public final static By byOk=findBy("//button[contains(text(),'OK')]");
	public final static By byModuleAlert=findBy("//a[contains(text(),'Module Alerts')]");
	public final static By byMonthly=findBy("//*[@id='select_timeseries_duration']/label[3]");
	//////////////////////////////Validation////////////////////////////////////////
	public static boolean ModuleLibraryPresent(){
		return isElementPresent(byModuleLibrary,"Module Library");
	}
	public static boolean ModulLibraryPresent(){
		return isElementPresent(byModulLibrary,"Module Library");
	}
	public static boolean BellIconPresent(){
		return isElementPresent(bybellIcon, "Bell Icon");
	}
	public static boolean byLinkedIconpresent(){
		return isElementPresent(byLinkedIcon, "Icon");
	}
	public static boolean isAddNewRowPresent(){
		return isElementPresent(byAddNewRow,"Add New Row");
	}
	
	public static boolean byAddToDashSuccessMsgPresent(){
	return isElementPresent(byAddToDashSuccessMessage,"Module exitst");
	}
	////////////////////////////ClicElement//////////////////////////
	public  static void clickonQTestModule(){
	 List<WebElement>listOfQtestFiles=findElements(byQTestModuleArea, "Qtest Files");
	 System.out.println( listOfQtestFiles.size());
	 listOfQtestFiles.get(0).click();
	}
	
	public static void clickonFormulaView(){
		clickElement(byFormulaView,"click on Formula View");
	}
	
	public static void clickNewLinkIcon(){
		clickElement(byNewLinkIcon, "link File");
	}
	 public static void clickOnModuleAssumption(){
		  clickElement(byModuleAssumption,"Edit MetaData");
	  }
	  public static void clikOnAddNewRow(){
		  clickElement(byAddNewRowTab, "Add new row");
	  }
	  public static void clickSavebutton(){
		  clickElement(bySaveButton, "click on Save Button");
	  }
	  public static void clickOnAddNewRow(){
		  clickElement(byAddNewRow,"Add New Row");
	  }
	  public static void clickOnFormulTd(){
		  clickElement(byFormulTd,"Added Formula");
	  }
	public static void clickOnEditFormula(){
		clickElement(byEditFormula, "Editable");
	}
	public static void clickOnAboutModule(){
		clickElement(byAboutModule,"About Module");
	}
	public static void clickOnModuleAlert(){
		clickElement(byModuleAlert, "Module Alert");
	}
	public static void clickOnAddtoDash(){
		clickElement(byAddToDashBoard,"Add To DashBoard");
	}
	public static void clickOnLinkedModule(){
		List<WebElement>list=findElements(byLinkedData,"Linked Module");
		list.get(0).click();
		list.get(0).click();
	}
	////////////////SetText///////////
	public static void EntertoSearch(String sText){
		setText(bySearchText, "Search", sText);
	}
	public static void SetEditFormula(String sText){
		setText(byEditFormula, "set text", sText);
	}
	public static void clickOnOk(){
		clickElement(byOk,"Ok Button");
	}
	public static void clickOnQuatterly(){
		clickElement(byQuaterly, "Quaterly");
	}
	public static void clickOnMonthly(){
		clickElement(byMonthly,"Monthly");
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////Selector/////////////////////////////////////////////////////////////////////////////
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void ModelView(){
		BuildPage.clickBuidTab();
		sleepApplication(5000);
		uploadExcelModulePage.clickOnOperational();
		waitForPageLoad(10);
		List<WebElement> files= findElements(byNew_2ExcelFile,"Excel Sheet");
		System.out.println("INFO: count of sheet"+files.size());
		waitForPageLoad(10);
		files.get(0).click();
		waitForPageLoad(20);
		sleepApplication(3000);
		clickonFormulaView();
		waitForPageLoad(20);
		sleepApplication(5000);
		clickOnAboutModule();
		waitForPageLoad(20);
		sleepApplication(5000);
		clickOnModuleAlert();
		/*clickOnAddtoDash();
		sleepApplication(3000);
		clickonFormulaView();
		waitForPageLoad(20);
		sleepApplication(3000);
		clickEditMetadata();
		waitForPageLoad(20);
		sleepApplication(3000);
		clickOnAboutModule();
		waitForPageLoad(20);
		sleepApplication(3000);*/
		
		
		/*sleepApplication(3000);
		for(int i=0;i<5;i++){
		HoverActionsElement(bytdDatatoLink, "Revenu Category");
		waitForPageLoad(10);
		clickNewLinkIcon();
		//List<WebElement> HiddenIcon= findElements(bytdDatatoLink,"Excel Sheet");
	//	System.out.println(HiddenIcon.size());
		
		
	//	HiddenIcon.get(1).click();
		
		
		sleepApplication(1000);
		
		//System.out.println("move to link");
	//	List<WebElement> HiddenIcon= findElements(byNewLinkIcon,"NewLinkIcon");
		
		
		
		System.out.println("INFO: Find new Icon");
		sleepApplication(5000);
			EntertoSearch(Search);
	System.out.println("Enter Module Name");
		sleepApplication(5000);
		
		List<WebElement> file= findElements(byModuletoLink,"Link to Module");
		file.get(1).click();
		sleepApplication(2000);
	
		}*/
		
	}
	
	 public static void verifyBuildEditaMetada(){
      
		 BuildPage.clickBuidTab();
		  sleepApplication(5000);
		  uploadExcelModulePage.clickOnOperational();
		  List<WebElement> files= findElements(byNew_2ExcelFile,"Excel Sheet");
			System.out.println("File Name is :"+files.get(0).getText());
			sleepApplication(2000);
			files.get(1).click();
			sleepApplication(15000);
			clickOnModuleAssumption();
			waitForPageLoad(5);
			sleepApplication(7000);
			clickOnAddNewRow();
			sleepApplication(7000);
			List<WebElement> textbox= findElements(byAddNewRowData,"Excel Sheet");
			textbox.get(1).sendKeys("Revenue category222");
			for(int i=2;i<textbox.size();i++){
			textbox.get(i).sendKeys("420420");
			//System.out.println(i);
			sleepApplication(1000);
		}
			sleepApplication(3000);
			clickSavebutton();
			sleepApplication(5000);
	  }
	 public static void verifyFormulaView(String formula){
			BuildPage.clickBuidTab();
			sleepApplication(5000);
			uploadExcelModulePage.clickOnOperational();
			sleepApplication(2000);
			List<WebElement> files= findElements(byNew_2ExcelFile,"Excel Sheet");
			System.out.println("INFO: File Name is :"+files.get(0).getText());
			sleepApplication(2000);
			files.get(0).click();
			waitForPageLoad(200);
			sleepApplication(15000);
			clickonFormulaView();
			sleepApplication(5000);
			clickOnFormulTd();
			sleepApplication(2000);
			clickOnEditFormula();
			clear(byEditFormula);
			sleepApplication(3000);
			SetEditFormula(formula);
			sleepApplication(10000);
					 
	 }
	 
	 ///////////////////////////////Home Page Select ModuleView Time Session///////////////////////////////////////////////
	
	 public static void verifyModelView(){
		 	uploadExcelModulePage.clickOnOperational();
			waitForPageLoad(10);
			List<WebElement> files= findElements(byNew2HomelFile,"Excel Sheet");
			System.out.println("INFO: count of sheet"+files.size());
			waitForPageLoad(10);
			files.get(0).click();
			waitForPageLoad(20);
			sleepApplication(3000);
			clickOnQuatterly();
			waitForPageLoad(50);
			sleepApplication(3000);
			clickOnMonthly();
			
	 }
	 
	//////////////////////Add To DashBoard///////////////////////////////////
	 public static void addToDashBoardModul(){
			BuildPage.clickBuidTab();
			sleepApplication(5000);
			uploadExcelModulePage.clickOnOperational();
			waitForPageLoad(10);
			List<WebElement> files= findElements(byNew_2ExcelFile,"Excel Sheet");
			System.out.println("INFO: count of sheet"+files.size());
			waitForPageLoad(10);
			files.get(0).click();
			waitForPageLoad(20);
			clickOnAddtoDash();
			sleepApplication(3000);
		//	Assert.assertTrue(BuildTabModelView.ModuleLibraryPresent());
    }
}