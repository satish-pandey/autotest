package oncfo.Pages;
import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

public class uploadExcelModulePage extends BasePage{
public static String SheetCoun;
public static String fileCount;
public static int uploadedDone;
public static int uploadedSheet;
public static int sheetTobeupload;
	public final static By byUploadExcelModuleTitle = findBy("//h1[contaisn(text(),'Upload Excel Module')]"); 
	public final static By bySelectFileButton = findBy("file"); 
	public final static By byFileTypeSwitch = findBy("//span[@class='bootstrap-switch-label']"); 
	public final static By byNextButton = findBy("//button[contains(text(),'Next')]"); 
	public final static By byFileNameFeild = findBy("//span[@class='fileinput-filename']");
	public final static By byProcessingBar = findBy("//div[@class='sub_overlay']/img");
	public final static By byProgressMessage = findBy("//div[contains(text(),'Uploading is in progress')]");
	public final static By byQatest=findBy("//span[contains(text(),'QATest2')]");
	/****************************** Module Library Objects ***************************/
	public final static By byPublicTab = findBy("//div[@id='uploadModuleId']//span[contains(text(),'Public')]");
	public final static By byFilterTextBar = findBy("public"); 
	public final static By byOperational=findBy("//span[contains(text(),'Operational')]");
	/****************************** Upload Excel Module Objects ***************************/
	public final static By byExcelModuleTable = findBy("//div[c@class='table-scrollable']"); 
	public final static By byIndividualModuleRadio = findBy("//label[1]/input"); 
	public final static By byModuleSuiteRadio = findBy("//label[2]/input"); 
	public final static By bySaveButton = findBy("//button[contains(text(),'Save')]"); 
	public final static By bySourceFile= findBy("//*[@id='1810']/div[1]");
	public final static By byAssetsLink = findBy("//span[contains(text(),'Assets')]");
	public final static By byOkButton= findBy("//button[contains(text(),'OK')]");
	public final static By byEditText=findBy("//iframe[@security='restricted']");
	public final static By bySubmitButton=findBy("//*[@id='modulesDescription']/div[2]/div/div/button[1]");
	public final static By bydestinat=findBy("//span[contains(text(),'Public Modules')]");
	public final static By byModuleAssumption=findBy("//a[contains(text(),'Module Assumptions')]");
	public final static By bySheetCount=findBy("//table//tr");
	public final static By byAdministrateTab =findBy("//*[@id='tab_home']/div/div[1]/div/ul/li[3]/a");
	public final static By byApproveModuleTab= findBy("//a[contains(text(),'Approve Public Modules')]");
	public final static By byActionTabApprove=findBy("//*[@id='tab_home']/div/div[2]/div/div[2]/div/div[2]/div/table/tbody[18]/tr/td[5]/div/button[2]");
	//div[@class='tiles row drg_container rev1']/div[@data-public='public']
	//div[@ class='tiles row drg_container rev1']//div[@data-rev=1]update
	public final static By bySourceFileForPublic = findBy("//div[@class='tiles row drg_container rev1']/div[@data-public='public']");
	public final static By bysourceFileForPrivate=findBy("//div[@id='pertionalTab']//div[@class='portlet light bdr_build bodyContent']");
	public final static By bydestination=findBy("//span[contains(text(),'TestOC700')]");
	public final static By byPublicTab1= findBy("//a[contains(text(),'Public')]");
	public final static By byTablenum=findBy(".//*[@id='tab_build']//tbody/tr");
	public final static By byPrivateTab=findBy("//a[contains(text(),'Private')]");
	public final static By byPublicModule=findBy("//span[contains(text(),'Public Modules')]");
	public final static By bypublicSubMOdule=findBy("//div[@data-parent='19']");
	public final static By byHomepublicSubMOdule=findBy("//li[@data-parent='19']");
	public final static By byHomeTestOc700SubModule=findBy("//li[@data-parent='17']");
	public final static By byTestOc700SubModule=findBy("//div[@data-parent='17']");
	public final static By byWorkingCapital=findBy("//span[contains(text(),'Working Capital')]");
	public final static By byWorkingCapitalSubFile=findBy("//div[@data-parent='3']");
	public final static By byHomeWorkingCapitalSubFile=findBy("//li[@data-parent='3']");
	public final static By byEditMetadata=findBy("//a[contains(text(),'Edit Metadata')]");
	public final static By byFormulaView=findBy("//a[@href='#tab7']");	
	public final static By byAboutModule=findBy("//a[contains(text(),'About Module')]");
	public final static By byViewChart=findBy("//div[contains(text(),'View Chart')]");
	public final static By byBoldTab=findBy("//a[contains(text(),'Bold')]");
	public final static By byHomeTab = findBy("//a[contains(text(),'Home')]"); 
	public final static By bySelectTab=findBy("//select[@class='form-control input-large timeFrame']");
	public final static By byLineItemName=findBy("//td[@class='bg_color fx_colum']");
	public final static By byAddtoDashBoardTab=findBy("//span[contains(text(),'Dashboard')]");
	public final static By byselectFile =findBy("//input[@id='file']");
	public final static By byCompanyWide=findBy("//a[contains(text(),'Company Wide')]");
	public final static By byPersonalFile=findBy("//div[@id='pertionalTab']//div[@class='portlet light bdr_build bodyContent']");
	public final static By byPersonalTab=findBy(".//*[@id='uploadModuleId']/div[2]/div/div/div/label[1]/div/span");
	public final static By byPersonalFileDrag=findBy("//a[contains(text(),'Personal')]");
	////////////////////////////////////////////////////////////
	//////////////////////  Validators  ////////////////////////
	///////////////////////////////////////////////////////////

	public static boolean isPrivateTabPresent(){
		return isElementPresent(bysourceFileForPrivate, "Private");
	}
	public static boolean isUploadExcelPageLoaded(){
		return isElementPresent(byUploadExcelModuleTitle, "Upload Excel Module Title");	
	}

	public static boolean isSelectFileButtonPresent(){
		return isElementPresent(bySelectFileButton, "Select File Button");
	}

	public static boolean isExcelModuleTablePresent(){
		return isElementPresent(byExcelModuleTable, "Excel Module Table");
	}
	
	public static boolean isIndividualModuleRadioPresent(){
		return isElementPresent(byIndividualModuleRadio, "Individual Module Radio");
	}
	
		public static boolean isPublicTabPresent(){
		return isElementPresent(byPublicTab, "Public Tab");
	}
	public static boolean isProgressMessagePresent(){
		return isElementPresent(byProgressMessage, "Module Upload Success Message");
	}
	public static boolean isProcessingBarPresent(){
		return isElementPresent(byProcessingBar, "Processing Bar");
	}
	public static boolean issourceFileForPrivate(){
		return isElementPresent(bysourceFileForPrivate, "File");
	}
				//////////////////////////////
	public static boolean isViewChartPresent(){
		return isElementPresent(byViewChart,"View Chart");
	}
	public static boolean isBoldTabPresent(){
		return isElementPresent(byBoldTab,"Bold Tab");
	}
	
	public static boolean isSelectTabPresent(){
		return isElementEnabled(bySelectTab,"Select Tab");
	}
	
	
	/////////////////////////////////////////////////////
    //////////////////////  Clickers ///////////////////////////
    ///////////////////////////////////////////////////////////
	public static void clickOkButton(){
		clickElement(byOkButton,"click on OK");
	}
	public static void clickSelectFileButton(){
		clickElement(bySelectFileButton, "SelectFile Button");
	}
	public static void clickFileTypeSwitch(){
		clickElement(byFileTypeSwitch, "Create Account link");
	}
	public static void clickNextButton(){
		clickElement(byNextButton, "Next Button ");
	}
	public static void clickPublicTab(){
		clickElement(byPublicTab, "Public Tab");
	}
	public static void clickOnPublicModule(){
		clickElement(byPublicModule,"PublicTab");
	}
	public static void clickFilterTextBar(){
		clickElement(byFilterTextBar, "Filter Text Bar");
	}
    public static void clickIndividualModuleRadio(){
		clickElement(byIndividualModuleRadio, "Individual Module Radio");
	}
	public static void clickModuleSuiteRadio(){
		clickElement(byModuleSuiteRadio, "Module Suite Radio");
	}
	public static void clickSaveButton(){
		clickElement(bySaveButton, "Save Button");
	}
	public static void clickSubmitButton(){
		clickElement(bySubmitButton,"clik on Submitbutton");
	}
	 public void getPageTitle(){
	    	String title=driver.getTitle();
	    	 System.out.println("INFO: Title for this page is :"+title);
	     }
	 public static void clickOnbyPublicTab1(){
		 clickElement(byPublicTab1, "click on Public");
	 }
	 public static void clickOnWorkingCapital(){
			clickElement(byWorkingCapital,"working Capital" );
			System.out.println("clicked OnWorkingCapital");
		}
	 public static void clickEditMetadata(){
		  clickElement(byEditMetadata,"Edit MetaData");
	  }
	 public static void clickonFormulaView(){
			clickElement(byFormulaView,"click on Formula View");
		}
	public static void clickAboutModule(){
		clickElement(byAboutModule,"Module Assumption");
	}
	public static void clickOnHomeTab(){
		clickElement(byHomeTab, "Home Tab");
	}
	public static void clickModuleAssumption(){
		clickElement(byModuleAssumption,"Module Assumption");
	}
	public static void clickOnAddtoDashBoardTab(){
		clickElement(byAddtoDashBoardTab,"Add To DashBoard");
	}
	public static void clickOnCompanyWide(){
		clickElement(byCompanyWide,"Company Wide");
	}
	public static void clickOnPersonal(){
		clickElement(byPersonalTab,"Personal");
	}
	
	public static void clickOnPersonaFileTab(){
		clickElement(byPersonalFileDrag,"Personal File");
	}
	public static String sheetCount(){
		List<WebElement>list=findElements(bySheetCount,"Sheet Count");
		SheetCoun=Integer.toString(list.size()-1);
		return SheetCoun;
	}
	public static void uploadExcel(String excelPath){
		  setText(byselectFile,"Select file", excelPath);
	}
	public static void clickOnOperational(){
		clickElement(byOperational, "clicked on Operationas");
	}
	
	 ////////////////////////////////////////////////////////////
    //////////////////////  Helper ///////////////////////////
    ///////////////////////////////////////////////////////////
	
public static void uploadExcelbyPrivate(String excelPath,String restricted) throws AWTException{
		HomePage.clickBuidTab();
		ExcelValidation.clickOnCreateMOdule();
		HomePage.clickUploadingExcelLink();
		sleepApplication(1000);
		clickOnPersonal();
		uploadExcel(excelPath);
		sleepApplication(2000);
		clickNextButton();
		waitForPageLoad(30);
		sleepApplication(30000);
		sheetCount();
		System.out.print("INFO: Sheet to be upload is : "+SheetCoun+"\n");
		clickSaveButton();
			waitForPageLoad(10);	
	 }

  	public static String FileCount(){
	List<WebElement>list=findElements(bysourceFileForPrivate, "File Count");
	return fileCount= Integer.toString(list.size());
} 
  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////////////////////DragAndDropFile////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  	
  public static void DragandDropFile(){
		BuildPage.clickBuidTab();
		sleepApplication(2000);
		clickOnPersonaFileTab();
		sleepApplication(2000);
		List<WebElement>file=findElements(byPersonalFile, "Files");
		int j=file.size()-1;
		for(int i=0; i<j;i++){
			System.out.println("file count is "+i);
		DragAndDropFiles(bysourceFileForPrivate, " ", byOperational, "New_2");
		clickOkButton();
		waitForElement(bysourceFileForPrivate,30," ");
			
	}
 }
	
}









