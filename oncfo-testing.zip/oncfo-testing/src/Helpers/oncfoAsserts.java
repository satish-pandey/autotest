
package Helpers;

import org.testng.Assert;

public class oncfoAsserts {

	
	public static void assertTrue(boolean condition){
		Assert.assertTrue(condition);
	}
	public void assertFalse(boolean condition){
		Assert.assertFalse(condition);
	}
	
	public void assertEquals(String actual, String expected,String message ){
		Assert.assertEquals(actual, expected,"message");
	}
	
	public void assertNotEquals(String actual, String expected){
		Assert.assertNotEquals(actual, expected);
	}
	
	
}
