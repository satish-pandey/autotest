
package Helpers;

import oncfo.Pages.BasePage;

import java.security.SecureRandom;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Helper extends BasePage{
	public ExtentReports report;
	public ExtentTest logger;


	@BeforeClass
	public void startSetup(){
		report= new ExtentReports("D:\\backup\\oncfo-testing\\Test Report\\Test-Report.html");
	}
 
  @AfterMethod
  public void closeSetup(ITestResult result)
	{
		if(ITestResult.FAILURE==result.getStatus())
		{
			try{  
				captureScreenshot(result);
		String image=logger.addScreenCapture("D:\\backup\\oncfo-testing\\ScreenCapture\\"+result.getName()+".png");
		logger.log(LogStatus.FAIL,"Verification");
			} 
	        catch (Exception e){	 
	        	System.out.println("Exception while taking screenshot "+e.getMessage());
	         } 
		}else if(result.getStatus()==ITestResult.SKIP){
			logger.log(LogStatus.SKIP, "Test skipped "+ result.getThrowable());
		}else{
			logger.log(LogStatus.PASS, "Test Passed ");
		}
		System.out.println("INFO: Inside CloseSetup");
		closeSession();
		System.out.println("INFO: CloseSetup Done");
	
	}
  @AfterMethod
	public void CloseSetUp(){
		System.out.println("INFO: Inside close setup");
		closeSession();
		System.out.println("INFO: Initial close done");
	}
	  
	  
	   public static String getRandomString(int length){
	   final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	   SecureRandom rnd = new SecureRandom();
	   StringBuilder sb = new StringBuilder(length);
	     for( int i = 0; i < length; i++ ) 
	        sb.append( AB.charAt( rnd.nextInt(AB.length())));
	         return sb.toString();
	    
	   }
	   public static String getRandomNumber(int length){
		   final String AB = "0123456789";
		   SecureRandom rnd = new SecureRandom();
		   StringBuilder sb = new StringBuilder(length);
		     for( int i = 0; i < length; i++ ) 
		        sb.append( AB.charAt( rnd.nextInt(AB.length())));
		         return sb.toString();
		    
		   }
	   
	   public static String getNewRandomUser(){
	    String user = "TestUser";
	    user=user.concat(getRandomString(8));
	   return user.concat("@Onfoc.com");
	   }
  

}
