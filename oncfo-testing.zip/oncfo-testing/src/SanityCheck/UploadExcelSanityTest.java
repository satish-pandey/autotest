package SanityCheck;
import java.awt.AWTException;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Helpers.Helper;
import oncfo.Pages.AddModelPage;
import oncfo.Pages.AdminEmailLoginPage;
import oncfo.Pages.BuildTabModelView;
import oncfo.Pages.ExcelValidation;
import oncfo.Pages.HomePage;
import oncfo.Pages.LoginPage;
import oncfo.Pages.SelectModelPage;
import oncfo.Pages.uploadExcelModulePage;
public class UploadExcelSanityTest extends Helper {
   
	@BeforeMethod
	public void InitialSetUp(Method method){
		System.out.println("INFO : Inside Initial setup");
		logger= report.startTest(method.getName());
		if(method.getName().contains("DragAndDropFile"))
		{
			InitialConfigDragAndDrop();
		}
		else{
			InitialConfig();
		}
	}
	@Test(priority=1)
	public void uploadExcelPrivate() throws InterruptedException, IOException, AWTException{
			LoginPage.login(getCurrentUserName(), getCurrentPassword());
		   	Assert.assertTrue(HomePage.isHomePageLoaded(),"Home");
		   /*	AddModelPage.AddModel();
		  	waitForPageLoad(30);
		  	driver.navigate().refresh();*/
		  	SelectModelPage.SelectModel();
		   	driver.navigate().refresh();
		   	waitForPageLoad(30);
		   	String path = System.getProperty("user.dir");
			ExcelValidation.excelValidation(path+"\\Quickbooks (IS-BS-CF --- Core _ Expenses).xlsx");
			Assert.assertTrue(ExcelValidation.isHeadingPresent());
			sleepApplication(3000);
			
			uploadExcelModulePage.uploadExcelbyPrivate(path+"\\Tax Core.xlsx"," FILE ");	
			Assert.assertTrue(uploadExcelModulePage.isProgressMessagePresent());
		   	sleepApplication(10000);
		   	driver.close();
		  	AdminEmailLoginPage.EmialLogin("sandbox@onplan.co", "2017<onP!an>", "Tax Core.xlsx");
		   //	Assert.assertTrue(AdminEmailLoginPage.ExcelFileisPresent());
		   	
	}
	
		@Test(priority=2)
	public void DragAndDropFile(){
		
			LoginPage.login(getCurrentUserName(), getCurrentPassword());
			Assert.assertTrue(HomePage.isHomePageLoaded(),"Home");
			uploadExcelModulePage.DragandDropFile();
			Assert.assertTrue(uploadExcelModulePage.isPrivateTabPresent());
			
	}
	
	@Test(priority=3)
	public void VerifyModelView() throws InterruptedException, IOException, AWTException{
			LoginPage.login(getCurrentUserName(), getCurrentPassword());
		   	Assert.assertTrue(HomePage.isHomePageLoaded(),"Home");
			BuildTabModelView.ModelView();
			Assert.assertTrue(BuildTabModelView.ModuleLibraryPresent());
	}
	

	
	////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Test(priority=5)
	public void VerifyHomeModelView() throws InterruptedException, IOException, AWTException{
			LoginPage.login(getCurrentUserName(), getCurrentPassword());
		   	Assert.assertTrue(HomePage.isHomePageLoaded(),"Home");
		   	BuildTabModelView.verifyModelView();
			Assert.assertTrue(BuildTabModelView.ModulLibraryPresent());
	}
	
/*	@Test(priority=5)
	public void VerifyEditModuleArea() throws InterruptedException, IOException, AWTException{
			LoginPage.login(getCurrentUserName(), getCurrentPassword());
		   	Assert.assertTrue(HomePage.isHomePageLoaded(),"Home");
		   	AddModelPage.EditModuleArea();
		   	Assert.assertTrue(AddModelPage.isSussessMsgPresent(),"Update Successfully");
}*/
}